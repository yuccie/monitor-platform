exports.static = true;

exports.vuessr = {
  enable: true,
  package: 'egg-view-vue-ssr'
};

exports.mongoose = {
  enable: true,
  package: 'egg-mongoose',
};