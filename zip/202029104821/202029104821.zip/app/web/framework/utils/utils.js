export function removeHTML(input) {
  return input;
}


export function formatDate(input) {
  return input;
}

export function getUrlParameter(url) {
  return url;
}