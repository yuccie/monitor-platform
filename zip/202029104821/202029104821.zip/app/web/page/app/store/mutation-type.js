'use strict';

export const SET_ARTICLE_LIST = 'SET_ARTICLE_LIST';
export const SET_ARTICLE_DETAIL = 'SET_ARTICLE_DETAIL';